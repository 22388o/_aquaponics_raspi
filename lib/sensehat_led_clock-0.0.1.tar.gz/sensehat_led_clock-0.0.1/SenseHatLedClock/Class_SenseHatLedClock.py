import time
try:
    from sense_hat import SenseHat
    imported_sense_hat = True
except ImportError:
    pass
    imported_sense_hat = False


class LedClock:
    def __init__(self):
        if imported_sense_hat:
            self.sense = SenseHat()
            self.sense.low_light = False

        self.nubers     = NUMBERS_8x8
        self.perimeter  = PERIMETER
        self.colortable = COLORTABLE

        self.delta_t_h = 0
        self.delta_t_m = 0

    def run(self, duration: int = 120, heartbeat: int = 2, delta_t_h: float = 0, delta_t_m: float = 0):
        if delta_t_h: self.delta_t_h = delta_t_h
        if delta_t_m: self.delta_t_m = delta_t_m
        time_now = time.time()
        time_at_end = time_now + duration
        while time_now <= time_at_end:
            if duration: time_now = time.time()  # if no duration defined, infinite loop
            cst = time.time() - 3600 * self.delta_t_h - 60 * self.delta_t_m  # Current System Time
            dst = time.gmtime(cst)  # Detailed System Time
            current_time_string = time.strftime("%H:%M", dst)
            self.update(timestring=current_time_string)
            time.sleep(heartbeat)

    def update(self, timestring: str):
        """=== Method name: update =====================================================================================
        Method takes in an HH:MM syntax time-string and renders it using the LED matrix with a clock style.
        ========================================================================================== by Sziller ==="""
        time_as_list = timestring.split(":")
        hour, minute = int(time_as_list[0]), int(time_as_list[1])
        unit = (28.0 / 60)
        min_unit = minute * unit + 1
        bin_matrix_hours = list_flatten(NUMBERS_8x8[hour])
        bin_matrix_perim_comp = []
        for row in self.perimeter:
            bin_matrix_perim_comp.append(logical_list_entry_limit_substitute(row, min_unit, 0, 1))
        bin_matrix_perim = list_flatten(bin_matrix_perim_comp)

        col_matrix_hours = logical_list_entry_substitute(bin_matrix_hours,
                                                         self.colortable['background'],
                                                         self.colortable['number'])
        col_matrix_perim = logical_list_entry_substitute(bin_matrix_perim,
                                                         self.colortable['background'],
                                                         self.colortable['perim'])
        image = logical_list_combine_adv(col_matrix_perim,
                                         col_matrix_hours,
                                         self.colortable['background'])
        if imported_sense_hat:
            self.sense.set_pixels(image)
        else:
            print(image)


def logical_list_entry_limit_substitute(list_in, treshold, false, true):
    """converts logical lists entries into entries
    represented by "false" or "true"
    """
    # return [true if _ == int(treshold) else false for _ in list_in]
    return [true if 0 < _ <= int(treshold) else false for _ in list_in]


def logical_list_entry_substitute(list_in, false, true):
    """converts logical lists entries into entries
    represented by 'false' or 'true' """
    return [false if _ == 0 else true for _ in list_in]


def list_display_dundle(list_in: list, sequence_length: int):
    counter = 0
    times = len(list_in)
    while counter < times:
        line = ""
        sec_times = sequence_length
        loc_counter = 0
        while loc_counter < sec_times:
            if counter + loc_counter < times:
                line += " " + str(list_in[counter + loc_counter])
            loc_counter += 1
        counter += loc_counter


def data_leading_zero(integer: int, digits: int):
    str_integer = str(int(integer))
    act_digits = len(str_integer)
    lead = ""
    for _ in range(digits - act_digits):
        lead += '0'
    return lead + str_integer


def fifo_list(list_in: list, data_in, max_length=False):
    answer = list(list_in)
    if not max_length:
        max_length = len(answer)
    answer.append(data_in)
    while len(answer) > max_length:
        del answer[0]
    return answer


def list_dict_fifo_extend_w_dist(listdict: dict, dict_in: dict, max_length=10):
    answer = {}
    for k, v in list(listdict.items()):
        answer[k] = fifo_list(list_in=v, data_in=dict_in[k], max_length=max_length)
    return answer


def logical_list_combine(list_base, list_add):
    counter = 0
    total = len(list_base)
    answer = []
    while counter < total:
        list_base_i = list_base[counter]
        if list_base_i:
            answer.append(list_base_i)
        else:
            answer.append(list_add[counter])
        counter += 1
    return answer


def logical_list_combine_adv(list_base, list_add, neutral):
    counter = 0
    total = len(list_base)
    answer = []
    while counter < total:
        list_base_i = list_base[counter]
        if list_base_i and list_base_i != neutral:
            answer.append(list_base_i)
        else:
            answer.append(list_add[counter])
        counter += 1
    return answer


def list_flatten(list_in):
    answer = []
    for x in list_in:
        for y in x:
            answer.append(y)
    return answer


COLORTABLE = {'background': [0, 0, 0], 'number': [150, 150, 150], 'perim': [0, 255, 0]}
NUMBERS_8x8 = {
        0:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        1:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 1, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        2:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 1, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        3:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        4:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 1, 1, 0, 0],
             [0, 0, 0, 1, 0, 1, 0, 0],
             [0, 0, 1, 1, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        5:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 1, 0, 0],
             [0, 0, 1, 0, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        6:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        7:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 0, 1, 0, 0, 0],
             [0, 0, 0, 1, 0, 0, 0, 0],
             [0, 0, 0, 1, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        8:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        9:  [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 1, 0, 0],
             [0, 0, 0, 1, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        10: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        11: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 1, 0, 1, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        12: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 1, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        13: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 1, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        14: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 1, 0, 0, 0],
             [0, 1, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        15: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 1, 1, 0, 1, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 0, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        16: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 1, 0],
             [0, 1, 1, 0, 1, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 0, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        17: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 1, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 1, 0, 0, 0],
             [0, 0, 1, 0, 1, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        18: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        19: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 1, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 0, 1, 0, 1, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        20: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 0, 1, 1, 0, 1, 0],
             [0, 0, 0, 1, 1, 0, 1, 0],
             [0, 0, 1, 0, 1, 0, 1, 0],
             [0, 1, 0, 0, 1, 0, 1, 0],
             [0, 1, 1, 1, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        21: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 0, 1, 1, 1, 0, 0],
             [0, 0, 0, 1, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 0, 0, 0, 1, 0, 0],
             [0, 1, 1, 1, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        22: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 0, 1, 1, 0, 1, 0],
             [0, 0, 0, 1, 0, 0, 1, 0],
             [0, 0, 1, 0, 0, 1, 0, 0],
             [0, 1, 0, 0, 1, 0, 0, 0],
             [0, 1, 1, 1, 1, 1, 1, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]],
        23: [[0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 1, 0, 1, 1, 1, 0],
             [0, 1, 0, 1, 0, 0, 1, 0],
             [0, 0, 0, 1, 0, 1, 0, 0],
             [0, 0, 1, 0, 0, 0, 1, 0],
             [0, 1, 0, 0, 1, 0, 1, 0],
             [0, 1, 1, 1, 0, 1, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0]]}
PERIMETER = [[25, 26, 27, 28,  1,  2,  3,  4],
             [24,  0,  0,  0,  0,  0,  0,  5],
             [23,  0,  0,  0,  0,  0,  0,  6],
             [22,  0,  0,  0,  0,  0,  0,  7],
             [21,  0,  0,  0,  0,  0,  0,  8],
             [20,  0,  0,  0,  0,  0,  0,  9],
             [19,  0,  0,  0,  0,  0,  0,  10],
             [18, 17, 16, 15, 14, 13, 12,  11]]


if __name__ == "__main__":
    clock = LedClock()
    clock.run(duration=0)
