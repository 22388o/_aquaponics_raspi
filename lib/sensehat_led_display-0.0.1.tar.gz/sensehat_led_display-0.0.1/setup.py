#!/usr/bin/python3.4

from setuptools import setup

'''
setup function to be run when creating packages for Organica
command to be typed in:
python setup.py sdist
python setup.py sdist bdist_wheel
'''

setup(
    name='sensehat_led_display',  # package name, used at pip or tar.
    version='0.0.1',  # version Nr.... whatever
    packages=["SenseHatLedDisplay"],  # string list of packages to be translated
    url='',  # if url is used at all
    license='',  # ...
    author='sziller',  # well obvious
    author_email='sziller@gmail.com',  # well obvious
    description='SenseHat mounted 8x8 sized LED-display',  # well obvious
    install_requires=[                  # ATTENTION! Wheel file needed, depending on environment
                      ],
    dependency_links=[],  # if dependent on external projects
)
