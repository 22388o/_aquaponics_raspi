def picture(**kwargs):
    coldict = kwargs['coldict']
    title = kwargs['title']
    image = IMAGES[title]
    return [coldict[_] for _ in image]

IMAGES = {
    "sziv":
        [0, 0, 7, 0, 0, 7, 0, 0,
         0, 7, 0, 7, 7, 0, 7, 0,
         7, 0, 0, 0, 0, 0, 0, 7,
         7, 0, 0, 0, 0, 0, 0, 7,
         7, 7, 0, 0, 0, 0, 7, 0,
         0, 0, 7, 0, 0, 7, 0, 0,
         0, 0, 0, 7, 7, 0, 0, 0,
         0, 0, 0, 0, 0, 0, 0, 0]
}